package Controller;

import Connection.MyConnection;
import Model.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class CadImangens {

    MyConnection conex = new MyConnection();
    Arquivo img = new Imagem();

    public void Salvar(Imagem img) {
        conex.Connection();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into arquivos (Id, Tipo, Nome, Tamanho, Data_Arq) values(?,?,?,?,?)");
            pst.setInt(1, img.getId());
            pst.setString(2, img.getTipo());
            pst.setString(3, img.getNome());
            pst.setString(4, img.getTamanho());
            pst.setString(5, img.getData());
            pst.execute();
            PreparedStatement pst1 = conex.con.prepareStatement("insert into imagem (ID_IMG, Qualidade, Extensão_Img, Dados_imagem) values(?,?,?,?)");
            pst1.setInt(1, img.getId());
            pst1.setString(2, img.getQualidade());
            pst1.setString(3, img.getExtencao());
            pst1.setString(4, img.getCaminho());
            pst1.execute();
            JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir dados." + ex);
        }
        conex.Dosconecta();
    }

    public Imagem buscaImagem(Imagem img) {
        //instanciar conexão
        conex.Connection();
        conex.executaSql("SELECT ID_IMG, Nome, Tipo, Extensão_Img FROM arquivos, imagem WHERE ID_IMG LIKE'%" + img.getPesquisa() + "%'");
        try {
            conex.rs.first();
            img.setId(conex.rs.getInt("ID_IMG"));
            img.setNome(conex.rs.getString("Nome"));
            img.setExtencao(conex.rs.getString("Extensão_Img"));
            img.setTipo(conex.rs.getString("Tipo"));
        } catch (SQLException ex) {
            JOptionPane.showConfirmDialog(null, "Erro de banco" + ex);
        }
        conex.Dosconecta();

        return img;
    }

    public void Editar(Imagem img) {
        conex.Connection();
        try {

            PreparedStatement pst = conex.con.prepareStatement("update arquivos set ID = ?, Tipo = ?, Nome = ?, Tamanho = ?, Data_Arq = ? where ID = ?");
            pst.setInt(1, img.getId());
            pst.setString(2, img.getTipo());
            pst.setString(3, img.getNome());
            pst.setString(4, img.getTamanho());
            pst.setString(5, img.getData());
            pst.execute();
            PreparedStatement pst1 = conex.con.prepareStatement("update imagem set ID_IMG = ?, Qualidade = ?, Extensão_Img = ?, Dados_imagem = ? where ID_IMG = ?");
            pst1.setInt(1, img.getId());
            pst1.setString(2, img.getQualidade());
            pst1.setString(3, img.getExtencao());
            pst1.setString(4, img.getCaminho());
            pst1.execute();
            JOptionPane.showMessageDialog(null, "Dados Alterados!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, dado não alterado!");
        }
        conex.Dosconecta();
    }

    public void Excluir(Imagem img) {
        conex.Connection();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from arquivos where (Id = ?)");
            pst.setInt(1, img.getId());
            PreparedStatement pst1 = conex.con.prepareStatement("delete from imagem where (ID_IMG = ?)");
            pst.setInt(1, img.getId());
            JOptionPane.showMessageDialog(null, "Dados deletados com sucesso.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar dados." + ex);
        }
        conex.Dosconecta();
    }
}
