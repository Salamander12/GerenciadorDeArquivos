package Controller;

import java.io.File;
import javax.swing.JOptionPane;

public class Inf_arquivo {

    public static void metodos(String caminho) {
        File arquivo = new File(caminho);

        if (arquivo.exists()) {
            JOptionPane.showMessageDialog(null, "O caminho especificado existe !\n");

            if (arquivo.isAbsolute()) {
                JOptionPane.showMessageDialog(null, "É um caminho absoluto");
            } else {
                JOptionPane.showMessageDialog(null, "Não é um caminho absoluto");
            }

            if (arquivo.isFile()) {
                JOptionPane.showMessageDialog(null, String.format("É um arquivo de tamanho %s bytes\n"
                        + "Cujo caminho é %s\n"
                        + "E está no diretório pai %s\n",
                        arquivo.length(), arquivo.getPath(), arquivo.getParent()));
            }

        } else {
            JOptionPane.showMessageDialog(null, "Endereço errado");
        }
    }

}
