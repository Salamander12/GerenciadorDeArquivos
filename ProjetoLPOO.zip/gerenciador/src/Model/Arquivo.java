package Model;

import java.util.Objects;

public class Arquivo {

    public int id;
    public String nome;
    public String Data;
    public String Tipo;
    public String Tamanho;

    public Arquivo(Integer id, String nome, String Data, String Tipo, String Tamanho) {
        this.id = id;
        this.nome = nome;
        this.Data = Data;
        this.Tipo = Tipo;
        this.Tamanho = Tamanho;
    }

    public Arquivo() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getData() {
        return Data;
    }

    public void setData(String Data) {
        this.Data = Data;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public String getTamanho() {
        return Tamanho;
    }

    public void setTamanho(String Tamanho) {
        this.Tamanho = Tamanho;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.id);
        hash = 89 * hash + Objects.hashCode(this.nome);
        hash = 89 * hash + Objects.hashCode(this.Data);
        hash = 89 * hash + Objects.hashCode(this.Tipo);
        hash = 89 * hash + Objects.hashCode(this.Tamanho);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Arquivo other = (Arquivo) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.Data, other.Data)) {
            return false;
        }
        if (!Objects.equals(this.Tipo, other.Tipo)) {
            return false;
        }
        if (!Objects.equals(this.Tamanho, other.Tamanho)) {
            return false;
        }
        return true;
    }

}
