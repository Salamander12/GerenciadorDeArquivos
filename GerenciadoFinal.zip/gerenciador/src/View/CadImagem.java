package View;

import Controller.CadImangens;
import Connection.MyConnection;
import Model.ModeloTabela;
import static Controller.Inf_arquivo.metodos;
import Model.Imagem;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public final class CadImagem extends javax.swing.JFrame {

    Imagem img = new Imagem();
    MyConnection conex = new MyConnection();
    CadImangens control = new CadImangens();

    public CadImagem() {
        initComponents();
        preencherTabela("SELECT ID_IMG, Nome, Tipo, Dados_imagem FROM arquivos, imagem ORDER BY Nome");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelImID = new javax.swing.JLabel();
        jLabelImNome = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jFormattedTextFieldImNome = new javax.swing.JFormattedTextField();
        jFormattedTextFieldImID = new javax.swing.JFormattedTextField();
        jFormattedTextFieldImData = new javax.swing.JFormattedTextField();
        jFormattedTextFieldImCaminho = new javax.swing.JFormattedTextField();
        jComboBoxImTipo = new javax.swing.JComboBox<>();
        jComboBoxImQualidade = new javax.swing.JComboBox<>();
        jComboBoxImExtencao = new javax.swing.JComboBox<>();
        jButtonImNovo = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonImEditar = new javax.swing.JButton();
        jButtonImCancelar = new javax.swing.JButton();
        jButtonImExcluir = new javax.swing.JButton();
        jButtonPesquisar = new javax.swing.JButton();
        jTextFieldImPesquisa = new javax.swing.JTextField();
        jLabelTamanho = new javax.swing.JLabel();
        jFormattedTextFieldTamanho = new javax.swing.JFormattedTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableCadImagem = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabelImID.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabelImID.setText("Id:");

        jLabelImNome.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabelImNome.setText("Nome:");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("Data:");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("Tipo:");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Caminho:");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Qualidade:");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setText("Extenção:");

        jFormattedTextFieldImNome.setEnabled(false);
        jFormattedTextFieldImNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextFieldImNomeActionPerformed(evt);
            }
        });

        jFormattedTextFieldImID.setEnabled(false);

        jFormattedTextFieldImData.setEnabled(false);

        jFormattedTextFieldImCaminho.setEnabled(false);

        jComboBoxImTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Imagem", "Video", "Texto", " " }));
        jComboBoxImTipo.setEnabled(false);
        jComboBoxImTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxImTipoActionPerformed(evt);
            }
        });

        jComboBoxImQualidade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "12mp", "16mp", "20mp", "4k" }));
        jComboBoxImQualidade.setEnabled(false);

        jComboBoxImExtencao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "JPEG", "PNG", "GIF", " " }));
        jComboBoxImExtencao.setEnabled(false);

        jButtonImNovo.setText("Novo");
        jButtonImNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonImNovoActionPerformed(evt);
            }
        });

        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });

        jButtonImEditar.setText("Editar");
        jButtonImEditar.setEnabled(false);
        jButtonImEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonImEditarActionPerformed(evt);
            }
        });

        jButtonImCancelar.setText("Cancelar");
        jButtonImCancelar.setEnabled(false);
        jButtonImCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonImCancelarActionPerformed(evt);
            }
        });

        jButtonImExcluir.setText("Excluir");
        jButtonImExcluir.setEnabled(false);
        jButtonImExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonImExcluirActionPerformed(evt);
            }
        });

        jButtonPesquisar.setText("Pesquisar");
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });

        jTextFieldImPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldImPesquisaActionPerformed(evt);
            }
        });

        jLabelTamanho.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabelTamanho.setText("Tamanho:");

        jFormattedTextFieldTamanho.setEnabled(false);

        jTableCadImagem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableCadImagem);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButtonImNovo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(36, 36, 36))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButtonImCancelar, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButtonSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButtonImExcluir, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButtonImEditar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelTamanho)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jFormattedTextFieldTamanho))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelImID)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jFormattedTextFieldImID))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabelImNome)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jFormattedTextFieldImNome, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jFormattedTextFieldImData))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxImTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jFormattedTextFieldImCaminho, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxImQualidade, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxImExtencao, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 625, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButtonPesquisar)
                                .addGap(18, 18, 18)
                                .addComponent(jTextFieldImPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, 528, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelImID)
                            .addComponent(jFormattedTextFieldImID, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelImNome)
                            .addComponent(jFormattedTextFieldImNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jFormattedTextFieldImData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jComboBoxImTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jFormattedTextFieldImCaminho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jComboBoxImQualidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jComboBoxImExtencao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jButtonImNovo))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButtonSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonImCancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonImEditar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonImExcluir)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTamanho)
                    .addComponent(jFormattedTextFieldTamanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonPesquisar)
                    .addComponent(jTextFieldImPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel1.setText("Cadastro de Imagens");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(254, 254, 254)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(new java.awt.Dimension(708, 576));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jFormattedTextFieldImNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextFieldImNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextFieldImNomeActionPerformed

    private void jComboBoxImTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxImTipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxImTipoActionPerformed

    private void jTextFieldImPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldImPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldImPesquisaActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        img.setId(Integer.parseInt(jFormattedTextFieldImID.getText()));
        img.setNome(jFormattedTextFieldImNome.getText());
        img.setData(jFormattedTextFieldImData.getText());
        img.setTipo((String) jComboBoxImTipo.getSelectedItem());
        metodos(jFormattedTextFieldImCaminho.getText());
        img.setCaminho(jFormattedTextFieldImCaminho.getText());
        img.setQualidade((String) jComboBoxImQualidade.getSelectedItem());
        img.setExtencao((String) jComboBoxImExtencao.getSelectedItem());
        img.setTamanho(jFormattedTextFieldTamanho.getText());
        control.Salvar(img);

        jFormattedTextFieldImID.setText("");
        jFormattedTextFieldImNome.setText("");
        jFormattedTextFieldImData.setText("");
        jFormattedTextFieldImCaminho.setText("");
        jFormattedTextFieldTamanho.setText("");

        jButtonSalvar.setEnabled(false);
        jFormattedTextFieldImID.setEnabled(false);
        jFormattedTextFieldImNome.setEnabled(false);
        jFormattedTextFieldImData.setEnabled(false);
        jComboBoxImTipo.setEnabled(false);
        jFormattedTextFieldImCaminho.setEnabled(false);
        jComboBoxImQualidade.setEnabled(false);
        jComboBoxImExtencao.setEnabled(false);
        jFormattedTextFieldTamanho.setEnabled(false);
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonImNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonImNovoActionPerformed
        jButtonSalvar.setEnabled(true);
        jFormattedTextFieldImID.setEnabled(true);
        jFormattedTextFieldImNome.setEnabled(true);
        jFormattedTextFieldImData.setEnabled(true);
        jComboBoxImTipo.setEnabled(true);
        jFormattedTextFieldImCaminho.setEnabled(true);
        jComboBoxImQualidade.setEnabled(true);
        jComboBoxImExtencao.setEnabled(true);
        jFormattedTextFieldTamanho.setEnabled(true);
    }//GEN-LAST:event_jButtonImNovoActionPerformed

    private void jButtonImExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonImExcluirActionPerformed
        int resposta = 0;
        resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir?");
        if (resposta == JOptionPane.YES_OPTION) {

            img.setId(Integer.parseInt(jFormattedTextFieldImID.getText()));
            control.Excluir(img);
        }

    }//GEN-LAST:event_jButtonImExcluirActionPerformed

    private void jButtonImCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonImCancelarActionPerformed
        jButtonSalvar.setEnabled(!true);
        jFormattedTextFieldImID.setEnabled(!true);
        jFormattedTextFieldImNome.setEnabled(!true);
        jFormattedTextFieldImData.setEnabled(!true);
        jComboBoxImTipo.setEnabled(!true);
        jFormattedTextFieldImCaminho.setEnabled(!true);
        jComboBoxImQualidade.setEnabled(!true);
        jComboBoxImExtencao.setEnabled(!true);
        jFormattedTextFieldTamanho.setEnabled(!true);
    }//GEN-LAST:event_jButtonImCancelarActionPerformed

    private void jButtonImEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonImEditarActionPerformed

        jButtonSalvar.setEnabled(true);
        jFormattedTextFieldImID.setEnabled(true);
        jFormattedTextFieldImNome.setEnabled(true);
        jFormattedTextFieldImData.setEnabled(true);
        jComboBoxImTipo.setEnabled(true);
        jFormattedTextFieldImCaminho.setEnabled(true);
        jComboBoxImQualidade.setEnabled(true);
        jComboBoxImExtencao.setEnabled(true);
        jFormattedTextFieldTamanho.setEnabled(true);
        jButtonImNovo.setEnabled(false);
        jButtonImExcluir.setEnabled(false);
        jButtonImEditar.setEnabled(false);
    }//GEN-LAST:event_jButtonImEditarActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed

        img.setPesquisa(jTextFieldImPesquisa.getText());
        Imagem Imgm = control.buscaImagem(img);
        jFormattedTextFieldImID.setText(String.valueOf(img.getId()));
        jFormattedTextFieldImNome.setText(Imgm.getNome());
        jComboBoxImExtencao.setSelectedItem(String.valueOf((Imgm.getExtencao())));
        jComboBoxImTipo.setSelectedItem(Imgm.getTipo());
        jButtonImEditar.setEnabled(true);
        jButtonImExcluir.setEnabled(true);
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadImagem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadImagem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadImagem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadImagem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadImagem().setVisible(true);
            }
        });
    }

    public void preencherTabela(String Sql) {
        ArrayList dados = new ArrayList();
        String[] colunas = new String[]{"ID", "Nome", "Tipo", "Caminho"};
        conex.Connection();
        conex.executaSql(Sql);
        try {
            conex.rs.first();
            // enquanto tiver dados ele apresenta
            do {
                dados.add(new Object[]{conex.rs.getInt("ID"), conex.rs.getString("Nome"), conex.rs.getString("Tipo"), conex.rs.getBlob("Dados_imagem")});

            } while (conex.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Lista de Imagens vazia\n" + ex);
        }
        ModeloTabela modelo = new ModeloTabela(dados, colunas);

        jTableCadImagem.setModel(modelo);
        jTableCadImagem.getColumnModel().getColumn(0).setPreferredWidth(35);
        //aumentar tamanho da coluna 
        jTableCadImagem.getColumnModel().getColumn(0).setResizable(false);
        jTableCadImagem.getColumnModel().getColumn(1).setPreferredWidth(220);
        jTableCadImagem.getColumnModel().getColumn(1).setResizable(false);
        jTableCadImagem.getColumnModel().getColumn(2).setPreferredWidth(80);
        jTableCadImagem.getColumnModel().getColumn(2).setResizable(false);
        jTableCadImagem.getColumnModel().getColumn(1).setPreferredWidth(120);
        jTableCadImagem.getColumnModel().getColumn(1).setResizable(false);
        jTableCadImagem.getTableHeader().setReorderingAllowed(false);
        // TABELA NÃO PODE SER DIMENSIONADA
        jTableCadImagem.setAutoResizeMode(jTableCadImagem.AUTO_RESIZE_OFF);
        // só selecionar um dado por vêz
        jTableCadImagem.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        conex.Dosconecta();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonImCancelar;
    private javax.swing.JButton jButtonImEditar;
    private javax.swing.JButton jButtonImExcluir;
    private javax.swing.JButton jButtonImNovo;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jComboBoxImExtencao;
    private javax.swing.JComboBox<String> jComboBoxImQualidade;
    private javax.swing.JComboBox<String> jComboBoxImTipo;
    private javax.swing.JFormattedTextField jFormattedTextFieldImCaminho;
    private javax.swing.JFormattedTextField jFormattedTextFieldImData;
    private javax.swing.JFormattedTextField jFormattedTextFieldImID;
    private javax.swing.JFormattedTextField jFormattedTextFieldImNome;
    private javax.swing.JFormattedTextField jFormattedTextFieldTamanho;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabelImID;
    private javax.swing.JLabel jLabelImNome;
    private javax.swing.JLabel jLabelTamanho;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableCadImagem;
    private javax.swing.JTextField jTextFieldImPesquisa;
    // End of variables declaration//GEN-END:variables

}
