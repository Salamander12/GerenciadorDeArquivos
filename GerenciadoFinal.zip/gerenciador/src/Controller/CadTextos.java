package Controller;

import Connection.MyConnection;
import Model.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class CadTextos {

    MyConnection conex = new MyConnection();
    Arquivo txt = new Texto();

    public void Salvar(Texto txt) {
        conex.Connection();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into arquivos (Tipo, ID, Nome, Tamanho, Data_Arq) values(?,?,?,?,?)");
            pst.setInt(2, txt.getId());
            pst.setString(1, txt.getTipo());
            pst.setString(3, txt.getNome());
            pst.setString(4, txt.getTamanho());
            pst.setString(5, txt.getData());
            pst.execute();
            PreparedStatement pst1 = conex.con.prepareStatement("insert into arq_texto (ExtensãoDeTexto, Num_palavras, ID_Text, caminho) values(?,?,?,?)");
            pst1.setString(1, txt.getExtencao());
            pst1.setString(2, txt.getNum_palavras());
            pst1.setInt(3, txt.getId());
            pst1.setString(4, txt.getCaminho());
            pst1.execute();
            JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir dados." + ex);
        }
        conex.Dosconecta();
    }

    public Texto buscaTexto(Texto txt) {
        //instanciar conexão
        conex.Connection();
        conex.executaSql("SELECT ID_Text, Nome, Tipo, ExtensãoDeTexto FROM arquivos, arq_texto WHERE ID_Text LIKE'%" + txt.getPesquisa() + "%'");
        try {
            conex.rs.first();
            txt.setId(conex.rs.getInt("ID_Text"));
            txt.setNome(conex.rs.getString("Nome"));
            txt.setExtencao(conex.rs.getString("ExtensãoDeTexto"));
            txt.setTipo(conex.rs.getString("Tipo"));
        } catch (SQLException ex) {
            JOptionPane.showConfirmDialog(null, "Erro de banco" + ex);
        }
        conex.Dosconecta();

        return txt;
    }

    public void Editar(Texto txt) {
        conex.Connection();
        try {

            PreparedStatement pst = conex.con.prepareStatement("update arquivos set ID = ?, Tipo = ?, Nome = ?, Tamanho = ?, Data_Arq = ? where ID = ?");
            pst.setInt(1, txt.getId());
            pst.setString(2, txt.getTipo());
            pst.setString(3, txt.getNome());
            pst.setString(4, txt.getTamanho());
            pst.setString(5, txt.getData());
            pst.execute();
            PreparedStatement pst1 = conex.con.prepareStatement("update arq_texto set ExtensãoDeTexto = ?, Num_palavras = ?, ID_Text = ?, caminho = ?) where ID_Text = ?");
            pst1.setString(1, txt.getExtencao());
            pst1.setString(2, txt.getNum_palavras());
            pst1.setInt(3, txt.getId());
            pst1.setString(4, txt.getCaminho());
            pst1.execute();
            JOptionPane.showMessageDialog(null, "Dados Alterados!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, dado não alterado!");
        }
        conex.Dosconecta();
    }

    public void Excluir(Texto img) {
        conex.Connection();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from arq_texto where (ID_Text = ?)");
            pst.setInt(1, img.getId());
            JOptionPane.showMessageDialog(null, "Dados deletados com sucesso.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar dados." + ex);
        }
        conex.Dosconecta();
    }

}
