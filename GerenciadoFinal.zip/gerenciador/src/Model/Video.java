package Model;

public class Video extends Arquivo {

    public Video(Integer _id, String _nome, String _Data, String _Tipo, String _Tamanho) {
        super(_id, _nome, _Data, _Tipo, _Tamanho);
    }

    private String duracao;
    private String qualidade;
    private String extencao;
    private String pesquisa;

    private String caminho;

    public Video() {

    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getQualidade() {
        return qualidade;
    }

    public void setQualidade(String qualidade) {
        this.qualidade = qualidade;
    }

    public String getExtencao() {
        return extencao;
    }

    public void setExtencao(String extencao) {
        this.extencao = extencao;
    }

    public String getPesquisa() {
        return pesquisa;
    }

    public void setPesquisa(String pesquisa) {
        this.pesquisa = pesquisa;
    }

    public String getCaminho() {
        return caminho;
    }

    public void setCaminho(String caminho) {
        this.caminho = caminho;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public String getData() {
        return Data;
    }

    @Override
    public String getTipo() {
        return Tipo;
    }

    @Override
    public String getTamanho() {
        return Tamanho;
    }

}
